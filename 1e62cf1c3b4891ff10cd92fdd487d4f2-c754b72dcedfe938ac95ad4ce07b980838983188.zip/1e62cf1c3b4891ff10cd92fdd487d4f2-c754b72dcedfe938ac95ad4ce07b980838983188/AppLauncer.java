import javax.swing.*;

public class AppLauncer {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
//                new loginGui().setVisible(true);
//                new registerGUI("Crypto Register").setVisible(true);
            }
        });
    }
}