import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class loginGui extends BaseFrame{


    public loginGui() {
        super("Cryptocurrency Portfolio Tracker");
    }

    @Override
    protected void addGuiComponents() {
        /*
        create banking app login label
         */
        JLabel cryptLog = new JLabel("Login");

        //set location of login
        cryptLog.setBounds(0,20,super.getWidth(),40);

        cryptLog.setFont(new Font("Dialog", Font.BOLD, 32));

        cryptLog.setHorizontalAlignment(SwingConstants.CENTER);

        add(cryptLog);


        /*
        USER NAME LABEL
         */

        JLabel user = new JLabel("Username:");

        user.setBounds(20,120,getWidth(),24);

        user.setFont(new Font("Dialog", Font.PLAIN, 20));

        add(user);

        //username text field

        JTextField username_input = new JTextField();
        username_input.setBounds(20, 160, getWidth()-50, 30);
        add(username_input);

        /*
        PASSWORD LABEL
         */

        JLabel password = new JLabel("Password:");

        password.setBounds(20,280,getWidth(),24);

        password.setFont(new Font("Dialog", Font.PLAIN, 20));

        add(password);


        //password text field
        JPasswordField pass = new JPasswordField();
        pass.setBounds(20, 320, getWidth()-50, 30);
        add(pass);


        /*
        login button
         */

        JButton button = new JButton("Login");
        button.setBounds(20,460,getWidth()-50,40);
        button.setFont(new Font("Dialog", Font.BOLD, 20));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = username_input.getText();
                String password = String.valueOf(pass.getPassword());

                //validate login
                Users user = MyJDBV.validateLogin(username, password);

                if(user != null){
                    loginGui.this.dispose();
                    //LAUNCH CRYPTO GUI HERE
                    new CryptoGui(user).setVisible(true);



                    //  JOptionPane.showMessageDialog(cryptogui, "Login Successful");
                }else{
                    JOptionPane.showMessageDialog(loginGui.this, "Login failed, please try again");
                }



            }
        });

        add(button);

        /*
        Register link
         */

        JLabel register = new JLabel("<html><a href=\"#\"> Don't have an account? Register Here! </a></html>");
        register.setBounds(20,510,getWidth()-10,30);
//        register.setFont(new Font("Dialog", Font.PLAIN, 20));
        register.setHorizontalAlignment(SwingConstants.CENTER);

        register.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                loginGui.this.dispose();
                new registerGUI("Crypto Register").setVisible(true);
            }
        });


            add(register);
    }
}
