import java.util.ArrayList;
import java.util.List;

public class Users {
    String username;
    String password;
    int accID;
    List<Crypto> portfolio;

    public Users(String user, String password, int id) {
        accID = id;
        username = user;
        this.password = password;
        portfolio = new ArrayList<>();
    }

    public int getAccID() { return accID; }
    public void setAccID(int accID) { this.accID = accID; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public List<Crypto> getPortfolio() { return portfolio; }
    public void addCrypto(Crypto crypto) { portfolio.add(crypto); }
}
