import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class registerGUI extends BaseFrame {


    public registerGUI(String title) {
        super("Crypto Register");
    }

    @Override
    protected void addGuiComponents() {
           /*
        create banking app login label
         */
        JLabel cryptLog = new JLabel("Register");

        //set location of login
        cryptLog.setBounds(0,20,super.getWidth(),40);

        cryptLog.setFont(new Font("Dialog", Font.BOLD, 32));

        cryptLog.setHorizontalAlignment(SwingConstants.CENTER);

        add(cryptLog);


        /*
        USER NAME LABEL
         */

        JLabel user = new JLabel("Username:");

        user.setBounds(20,120,getWidth(),24);

        user.setFont(new Font("Dialog", Font.PLAIN, 20));

        add(user);

        //username text field

        JTextField username_input = new JTextField();
        username_input.setBounds(20, 160, getWidth()-50, 30);
        add(username_input);

        /*
        PASSWORD LABEL
         */

        JLabel password = new JLabel("Password:");

        password.setBounds(20,220,getWidth(),24);

        password.setFont(new Font("Dialog", Font.PLAIN, 20));

        add(password);


        //password text field
        JPasswordField pass = new JPasswordField();
        pass.setBounds(20, 260, getWidth()-50, 30);
        add(pass);

        /*
        Re-type pass word LABEL
         */
        JLabel rePass = new JLabel("Retype Password:");

        rePass.setBounds(20,320,getWidth(),24);

        rePass.setFont(new Font("Dialog", Font.PLAIN, 20));

        add(rePass);

        //retype pass field
        JPasswordField repassF = new JPasswordField();
        repassF.setBounds(20, 360, getWidth()-50, 30);
        add(repassF);

        /*
        login button
         */

        JButton button = new JButton("Register");
        button.setBounds(20,460,getWidth()-50,40);
        button.setFont(new Font("Dialog", Font.BOLD, 20));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = username_input.getText();

                String password = String.valueOf(pass.getPassword());

                String re_password = String.valueOf(repassF.getPassword());

                if(checkUser(username, password, re_password )){
                   if(MyJDBV.registerUsers(username, password)){ //success
                       registerGUI.this.dispose();

                       loginGui login = new loginGui();
                       login.setVisible(true);

                       JOptionPane.showMessageDialog(login, "REGISTERED!");
                   }
                   else{
                       JOptionPane.showMessageDialog(registerGUI.this, "Error: Username already taken!");
                   }
                }
                else{
                    JOptionPane.showMessageDialog(registerGUI.this, "Error: Username must be 6 characters long\n" +
                            "and/or Password must match.");

                }
            }
        });
        add(button);

        /*
        Login in link
         */

        JLabel login = new JLabel("<html><a href=\"#\"> Have an account? Login Here! </a></html>");
        login.setBounds(20,510,getWidth()-10,30);
//        register.setFont(new Font("Dialog", Font.PLAIN, 20));
        login.setHorizontalAlignment(SwingConstants.CENTER);

        login.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                registerGUI.this.dispose();
                new loginGui().setVisible(true);
            }
        });

        add(login);
    }


    private boolean checkUser(String username, String password, String repassword){
        if(username.length() == 0 || password.length() == 0 || repassword.length() == 0){
            return false;
        }
        if(!password.equals(repassword)){
            return false;
        }
        if(username.length() < 6){
            return false;
        }
        return true;
    }

}
