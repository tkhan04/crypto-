import java.sql.*;

public class MyJDBV {




    // database configurations
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/login";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "Rahib2004";

//    public static void main(String[] args) {
//        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
//            System.out.println("Database connection successful!");
//        } catch (SQLException e) {
//            System.out.println("Failed to connect to the database.");
//            e.printStackTrace();
//        }
//    }


    // if valid return an object with the user's information
    public static Users validateLogin(String username, String password){
        try{
            // establish a connection to the database using configurations
            Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            // create sql query
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM users WHERE username = ? AND password = ?"
            );

            // parameter index referring to the iteration of the ? so 1 is the first ? and 2 is the second ?
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            // execute query and store into a result set
            ResultSet resultSet = preparedStatement.executeQuery();

            // next() returns true or false
            // true - query returned data and result set now points to the first row
            // false - query returned no data and result set equals to null
            if(resultSet.next()){
                // success
                // get id
                int userId = resultSet.getInt("id");


                // return user object
                return new Users(username, password, userId);
            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        // not valid user
        return null;
    }


    public static boolean registerUsers(String username, String password){

        try{
            if(!checkUser(username)){
                Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                PreparedStatement statement = connection.prepareStatement(
                        "INSERT INTO users(username, password) " +
                                "VALUES(?,?)"
                );

                statement.setString(1,username);
                statement.setString(2,password);

                statement.executeUpdate();

                return true;
            }


        } catch(SQLException e){
            e.printStackTrace();
        }

        return false;

    }

    //checks if user exist within database
    private static boolean checkUser(String username){
        try{
            Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

            PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM users WHERE username = ?"
            );

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            //means username is available!
            if(!resultSet.next()){
                return false;
            }

        }catch(SQLException e){
            e.printStackTrace();
        }

        return true;
    }






}

