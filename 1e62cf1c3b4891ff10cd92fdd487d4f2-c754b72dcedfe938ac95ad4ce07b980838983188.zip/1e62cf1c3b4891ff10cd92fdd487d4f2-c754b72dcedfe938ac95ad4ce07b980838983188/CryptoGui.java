import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CryptoGui extends BaseFrame {

    private DefaultTableModel tableModel;

    public CryptoGui(Users user) {
        super("Cryptocurrency Portfolio Tracker - Dashboard");
        setTitle("Welcome, " + user.getUsername());
    }

    @Override
    protected void addGuiComponents() {
        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome to your Crypto Portfolio Tracker!");
        welcomeLabel.setFont(new Font("Dialog", Font.BOLD, 24));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBounds(0, 20, getWidth(), 30);
        add(welcomeLabel);

        // Portfolio table
        String[] columnNames = {"Cryptocurrency", "Amount"};
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable portfolioTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(portfolioTable);
        tableScrollPane.setBounds(20, 80, getWidth() - 50, 200);
        add(tableScrollPane);

        // Input fields for adding cryptocurrencies
        JLabel cryptoLabel = new JLabel("Cryptocurrency:");
        cryptoLabel.setBounds(20, 300, 150, 20);
        cryptoLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(cryptoLabel);

        JTextField cryptoField = new JTextField();
        cryptoField.setBounds(150, 300, getWidth() - 200, 30);
        add(cryptoField);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(20, 350, 150, 20);
        amountLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(150, 350, getWidth() - 200, 30);
        add(amountField);

        JButton addButton = new JButton("Add to Portfolio");
        addButton.setBounds(20, 400, getWidth() - 50, 40);
        addButton.setFont(new Font("Dialog", Font.BOLD, 16));
        add(addButton);

        // Placeholder for graph
        JLabel graphLabel = new JLabel("Price Trend (Graph Placeholder)");
        graphLabel.setFont(new Font("Dialog", Font.ITALIC, 18));
        graphLabel.setHorizontalAlignment(SwingConstants.CENTER);
        graphLabel.setBounds(20, 460, getWidth() - 50, 150);
        graphLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(graphLabel);

        // Add button action
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String crypto = cryptoField.getText();
                String amount = amountField.getText();

                if (crypto.isEmpty() || amount.isEmpty()) {
                    JOptionPane.showMessageDialog(CryptoGui.this, "Please fill in both fields.");
                    return;
                }

                try {
                    double amountValue = Double.parseDouble(amount);
                    tableModel.addRow(new Object[]{crypto, amountValue});
                    cryptoField.setText("");
                    amountField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(CryptoGui.this, "Please enter a valid number for the amount.");
                }
            }
        });
    }

//    public static void main(String[] args) {
//        Users user = new Users("exampleUser", "examplePass", 1);
//        CryptoGui dashboard = new CryptoGui(user);
//        dashboard.setVisible(true);
//    }
}
